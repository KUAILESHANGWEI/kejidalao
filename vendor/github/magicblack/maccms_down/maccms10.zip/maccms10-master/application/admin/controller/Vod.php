<?php
namespace app\admin\controller;
use app\common\util\VodAuditService;
use app\common\util\VodPublishService;
use think\Cache;
use think\Db;

class Vod extends Base
{
    public function __construct()
    {
        parent::__construct();
        $this->view->config('view_path', APP_PATH . 'admin/view_new/');
    }

    public function data()
    {
        $param = input();
        $param['page'] = intval($param['page']) <1 ? 1 : $param['page'];
        $param['limit'] = intval($param['limit']) <1 ? $this->_pagesize : $param['limit'];

        $where = [];
        // 资源检测筛选（0 未检测 / 1 正常 / 2 检测失败 / 3 已自动停用 / 4 管理员停用）；字段由升级脚本补，未升级时不筛选
        if (\app\common\util\ContentCheck::hasColumns('vod') && in_array($param['check'] ?? '', ['0', '1', '2', '3', '4'], true)) {
            $where['vod_check_state'] = ['eq', intval($param['check'])];
        }
        if(!empty($param['type'])){
            $where['type_id|type_id_1'] = ['eq',$param['type']];
        }
        if(!empty($param['level'])){
            $where['vod_level'] = ['eq',$param['level']];
        }
        if(in_array($param['status'],['0','1','2','3','4'],true)){
            $where['vod_status'] = ['eq',$param['status']];
        }
        if(in_array($param['copyright'],['0','1'])){
            $where['vod_copyright'] = ['eq',$param['copyright']];
        }
        if(in_array($param['isend'],['0','1'])){
            $where['vod_isend'] = ['eq',$param['isend']];
        }
        if(!empty($param['lock'])){
            $where['vod_lock'] = ['eq',$param['lock']];
        }
        if(!empty($param['state'])){
            $where['vod_state'] = ['eq',$param['state']];
        }
        if(!empty($param['area'])){
            $where['vod_area'] = ['eq',$param['area']];
        }
        if(!empty($param['lang'])){
            $where['vod_lang'] = ['eq',$param['lang']];
        }
        if(in_array($param['plot'],['0','1'])){
            $where['vod_plot'] = ['eq',$param['plot']];
        }

        // 处理角色筛选 - 通过查询角色表判断是否有角色数据
        if(in_array($param['role'],['0','1'])){
            $roleVodIds = Db::name('role')->where('role_rid', '>', 0)->group('role_rid')->column('role_rid');
            if($param['role'] == '1'){
                // 有角色数据
                if(!empty($roleVodIds)){
                    $where['vod_id'] = ['in', $roleVodIds];
                } else {
                    // 如果没有任何角色数据，设置一个不可能匹配的条件
                    $where['vod_id'] = ['eq', 0];
                }
            } else {
                // 无角色数据
                if(!empty($roleVodIds)){
                    $where['vod_id'] = ['not in', $roleVodIds];
                }
            }
        }

        if(!empty($param['url'])){
            if($param['url']==1){
                $where['vod_play_url'] = '';
            }
        }
        if(!empty($param['points'])){
            $where['vod_points_play|vod_points_down'] = ['gt', 0];
        }
        if(!empty($param['pic'])){
            if($param['pic'] == '1'){
                $where['vod_pic'] = ['eq',''];
            }
            elseif($param['pic'] == '2'){
                $where['vod_pic'] = ['like','http%'];
            }
            elseif($param['pic'] == '3'){
                $where['vod_pic'] = ['like','%#err%'];
            }
        }
        if(!empty($param['weekday'])){
            $where['vod_weekday'] = ['like','%'.$param['weekday'].'%'];
        }
        if(!empty($param['wd'])){
            @set_time_limit(120);
            $param['wd'] = urldecode($param['wd']);
            $param['wd'] = mac_filter_xss($param['wd']);
            $like = mac_search_wd_like($param['wd']);
            if ($like) {
                $where['vod_name|vod_actor|vod_sub'] = $like;
            }
        }
        if(!empty($param['player'])){
            if($param['player']=='no'){
                $where['vod_play_from'] = [['eq', ''], ['eq', 'no'], 'or'];
            }
            else {
                $where['vod_play_from'] = ['like', '%' . $param['player'] . '%'];
            }
        }
        if(!empty($param['downer'])){
            if($param['downer']=='no'){
                $where['vod_down_from'] = [['eq', ''], ['eq', 'no'], 'or'];
            }
            else {
                $where['vod_down_from'] = ['like', '%' . $param['downer'] . '%'];
            }
        }
        if(!empty($param['server'])){
            $where['vod_play_server|vod_down_server'] = ['like','%'.$param['server'].'%'];
        }
        if (!empty($param['recycle'])) {
            $where['vod_recycle_time'] = ['>', 0];
        }
        $order='vod_time desc';
        if(in_array($param['order'],['vod_id','vod_hits','vod_hits_month','vod_hits_week','vod_hits_day'])){
            $order = $param['order'] .' desc';
        }

        if(!empty($param['repeat'])){
            if(!empty($param['cache'])){
                model('Vod')->createRepeatCache();
                return $this->success(lang('update_ok'));
            }

            if($param['page'] ==1){
                //使用缓存查看是否创建过缓存表
                $cacheResult = Cache::get('vod_repeat_table_created_time',0);
                //缓存时间超过7天和没有创建过缓存都会重建缓存
                if( $cacheResult == 0 || time() - $cacheResult > 604800){
                    model('Vod')->createRepeatCache();
                }
            }
            $order='vod_name asc';
            $res = model('Vod')->listRepeatData($where,$order,$param['page'],$param['limit']);
        }
        else{
            $res = model('Vod')->listData($where,$order,$param['page'],$param['limit']);
        }


        // 批量查询哪些视频有角色数据
        $vodIds = array_column($res['list'], 'vod_id');
        $vodIdsWithRole = [];
        $vodSeoStatusMap = [];
        if (!empty($vodIds)) {
            $roleData = Db::name('role')
                ->where('role_rid', 'in', $vodIds)
                ->where('role_rid', '>', 0)
                ->group('role_rid')
                ->column('role_rid');
            $vodIdsWithRole = array_flip($roleData); // 转为键值对，方便快速查找

            $seoRows = Db::name('seo_ai_result')
                ->field('seo_obj_id,seo_status')
                ->where('seo_mid', 1)
                ->where('seo_obj_id', 'in', $vodIds)
                ->where('seo_status', 'in', [1, 2])
                ->select();
            foreach ((array)$seoRows as $seoRow) {
                $vodSeoStatusMap[intval($seoRow['seo_obj_id'])] = intval($seoRow['seo_status']);
            }
        }

        foreach($res['list'] as $k=>&$v){
            $v['ismake'] = 1;
            if($GLOBALS['config']['view']['vod_detail'] >0 && $v['vod_time_make'] < $v['vod_time']){
                $v['ismake'] = 0;
            }
            // 标记是否有角色数据
            $v['vod_role'] = isset($vodIdsWithRole[$v['vod_id']]) ? 1 : 0;
            $v['seo_ai_status'] = isset($vodSeoStatusMap[$v['vod_id']]) ? intval($vodSeoStatusMap[$v['vod_id']]) : 0;
        }

        // 未升级站点缺 check_* 字段：补默认值，列表模板直接读取
        \app\common\util\ContentCheck::fillDefaults('vod', $res['list']);
        $this->assign('list',$res['list']);
        $this->assign('total',$res['total']);
        $this->assign('page',$res['page']);
        $this->assign('limit',$res['limit']);

        $param['page'] = '{page}';
        $param['limit'] = '{limit}';
        $this->assign('param',$param);
        $queryString = '?' . http_build_query($param);
        $this->assign('query_string',$queryString);
        //分类
        $type_tree = model('Type')->getCache('type_tree');
        $this->assign('type_tree',$type_tree);

        //播放器
        $this->assignBaseListByConfig();
        $this->assign('title',lang('admin/vod/title'));
        return $this->fetch('admin@vod/index');
    }

    public function batch()
    {
        $param = input();
        if (!empty($param)) {

            mac_echo('<style type="text/css">body{font-size:12px;color: #333333;line-height:21px;}span{font-weight:bold;color:#FF0000}</style>');

            if(empty($param['ck_del']) && empty($param['ck_level']) && empty($param['ck_status']) && empty($param['ck_lock']) && empty($param['ck_hits'])
                && empty($param['ck_points']) && empty($param['ck_copyright']) && empty($param['ck_type']) && empty($param['ck_tag']) && empty($param['ck_play'])
                && empty($param['ck_replace'])
            ){
                return $this->error(lang('param_err'));
            }


            if($param['ck_del']==2 && empty($param['player'])){
                return $this->error(lang('admin/vod/del_play_must_select_play'));
            }
            if($param['ck_del']==3 && empty($param['downer'])){
                return $this->error(lang('admin/vod/del_down_must_select_down'));
            }
            if (!empty($param['ck_status']) && intval($param['val_status'] ?? -1) === VodAuditService::STATUS_REJECTED) {
                $remarkErr = VodAuditService::rejectRemarkError($param['val_audit_remark'] ?? '');
                if ($remarkErr !== '') {
                    return $this->error($remarkErr);
                }
            }
            if (!empty($param['ck_status']) && intval($param['val_status'] ?? -1) === VodPublishService::STATUS_SCHEDULED) {
                $publishTime = VodPublishService::parsePublishTime($param['val_publish_time'] ?? 0);
                $scheduleErr = VodPublishService::scheduleTimeError(VodPublishService::STATUS_SCHEDULED, $publishTime);
                if ($scheduleErr !== '') {
                    return $this->error($scheduleErr);
                }
            }
            $where = $this->vodBatchFilterWhere($param);
            if($param['ck_del'] == 1){
                $res = model('Vod')->recycleData($where);
                mac_echo($res['code'] == 1 ? lang('recycle_ok') : $res['msg']);
                mac_jump( url('vod/batch') ,3);
                exit;
            }
            if($param['ck_del'] == 4){
                $res = model('Vod')->delData($where);
                mac_echo(lang('multi_del_ok'));
                mac_jump( url('vod/batch') ,3);
                exit;
            }


            if(empty($param['page'])){
                $param['page'] = 1;
            }
            if(empty($param['limit'])){
                $param['limit'] = 100;
            }
            if(empty($param['total'])) {
                $param['total'] = model('Vod')->countData($where);
                $param['page_count'] = ceil($param['total'] / $param['limit']);
            }

            if($param['page'] > $param['page_count']) {
                mac_echo(lang('multi_opt_ok'));
                mac_jump( url('vod/batch') ,3);
                exit;
            }
            mac_echo( "<font color=red>".lang('admin/batch_tip',[$param['total'],$param['limit'],$param['page_count'],$param['page']])."</font>");

            $page = $param['page_count'] - $param['page'] + 1;
            $order='vod_id desc';
            $res = model('Vod')->listData($where,$order,$page,$param['limit']);

            foreach($res['list'] as  $k=>$v){
                $where2 = [];
                $where2['vod_id'] = $v['vod_id'];

                $update = [];
                $des = $v['vod_id'].','.$v['vod_name'];

                if(!empty($param['ck_level']) && !empty($param['val_level'])){
                    $update['vod_level'] = $param['val_level'];
                    $des .= '&nbsp;'.lang('level').'：'.$param['val_level'].'；';
                }
                if(!empty($param['ck_status']) && isset($param['val_status'])){
                    $valStatus = intval($param['val_status']);
                    $update['vod_status'] = $valStatus;
                    $update['vod_audit_remark'] = '';
                    if ($valStatus === VodAuditService::STATUS_REJECTED) {
                        $update['vod_audit_remark'] = mb_substr(trim((string)$param['val_audit_remark']), 0, 255);
                        $update['vod_publish_time'] = 0;
                    } elseif ($valStatus === VodAuditService::STATUS_APPROVED) {
                        $update['vod_publish_time'] = 0;
                    } elseif ($valStatus === VodPublishService::STATUS_DRAFT) {
                        $update['vod_publish_time'] = 0;
                    } elseif ($valStatus === VodPublishService::STATUS_SCHEDULED) {
                        $update['vod_publish_time'] = VodPublishService::parsePublishTime($param['val_publish_time'] ?? 0);
                    } else {
                        $update['vod_publish_time'] = 0;
                    }
                    $des .= '&nbsp;'.lang('status').'：['.VodAuditService::statusText($param['val_status']).']；';
                }
                if(!empty($param['ck_copyright']) && isset($param['val_copyright'])){
                    $update['vod_copyright'] = $param['val_copyright'];
                    $des .= '&nbsp;'.lang('copyright').'：'.($param['val_copyright'] ==1 ? '['.lang('open').']':'['.lang('close').'') .'；';
                }
                if(!empty($param['ck_lock']) && isset($param['val_lock'])){
                    $update['vod_lock'] = $param['val_lock'];
                    $des .= '&nbsp;'.lang('lock').'：'.($param['val_lock']==1 ? '['.lang('lock').']':'['.lang('unlock').']').'；';
                }
                if(!empty($param['ck_hits']) && $param['val_hits_min']!='' && $param['val_hits_max']!='' ){
                    $update['vod_hits'] = rand($param['val_hits_min'],$param['val_hits_max']);
                    $des .= '&nbsp;'.lang('hits').'：'.$update['vod_hits'].'；';
                }
                if(!empty($param['ck_points']) && $param['val_points_play']!=''  ){
                    $update['vod_points_play'] = $param['val_points_play'];
                    $des .= '&nbsp;'.lang('points_play').'：'.$param['val_points_play'].'；';
                }
                if(!empty($param['ck_points']) && $param['val_points_down']!='' ){
                    $update['vod_points_down'] = $param['val_points_down'];
                    $des .= '&nbsp;'.lang('points_down').'：'.$param['val_points_down'].'；';
                }

                // 新增：批量修改分类
                if(!empty($param['ck_type']) && !empty($param['val_type'])){
                    $update['type_id'] = intval($param['val_type']);
                    $type_list = model('Type')->getCache();
                    if(isset($type_list[$update['type_id']])){
                        $id1 = intval($type_list[$update['type_id']]['type_pid']);
                        $update['type_id_1'] = $id1;
                    }
                    $des .= '&nbsp;'.lang('type').'：'.$update['type_id'].'；';
                }

                // 新增：批量修改标签
                if(!empty($param['ck_tag']) && !empty($param['val_tag'])){
                    $update['vod_tag'] = mac_filter_xss($param['val_tag']);
                    $des .= '&nbsp;'.lang('tag').'：'.$update['vod_tag'].'；';
                }

                // 新增：批量修改播放源
                if(!empty($param['ck_play']) && !empty($param['val_play'])){
                    $update['vod_play_from'] = $param['val_play'];
                    $des .= '&nbsp;'.lang('play_group').'：'.$param['val_play'].'；';
                }

                // 新增：批量替换功能
                if(!empty($param['ck_replace']) && !empty($param['replace_field']) && isset($param['replace_search'])){
                    $field = $param['replace_field'];
                    $replaceres = $this->batch_replace($field,$v,$param['replace_search'],$param['replace_with'],'vod');
                    if(isset($replaceres[$field])) $update[$field] = $replaceres[$field];

                    if(!empty($replaceres['des'])) $des .= $replaceres['des'];
                }

                if($param['ck_del'] == 2 || $param['ck_del'] ==3){
                    if($param['ck_del']==2) {
                        $pre = 'vod_play';
                        $par = 'player';
                        $des .= '&nbsp;'.lang('play_group').'：';
                    }
                    elseif($param['ck_del']==3){
                        $pre = 'vod_down';
                        $par='downer';
                        $des .= '&nbsp;'.lang('down_group').'：';
                    }


                    if($param[$par] == $v[$pre.'_from']){
                        $update[$pre.'_from'] = '';
                        $update[$pre.'_server'] = '';
                        $update[$pre.'_note'] = '';
                        $update[$pre.'_url'] = '';
                        $des .= lang('del_empty').'；';
                    }
                    else{
                        $vod_from_arr = explode('$$$',$v[$pre.'_from']);
                        $vod_server_arr = explode('$$$',$v[$pre.'_server']);
                        $vod_note_arr = explode('$$$',$v[$pre.'_note']);
                        $vod_url_arr = explode('$$$',$v[$pre.'_url']);

                        $key = array_search($param[$par],$vod_from_arr);
                        if($key!==false){
                            unset($vod_from_arr[$key]);
                            unset($vod_server_arr[$key]);
                            unset($vod_note_arr[$key]);
                            unset($vod_url_arr[$key]);

                            $update[$pre.'_from'] = join('$$$',$vod_from_arr);
                            $update[$pre.'_server'] = join('$$$',$vod_server_arr);
                            $update[$pre.'_note'] = join('$$$',$vod_note_arr);
                            $update[$pre.'_url'] = join('$$$',$vod_url_arr);
                            $des .= lang('del'). '；';
                        }
                        else{
                            $des .= lang('jump_over').'；';
                        }
                    }
                }

                mac_echo($des);
                $res2 = model('Vod')->where($where2)->update($update);
                if ($res2 !== false && isset($update['vod_status'])) {
                    \app\common\util\MeilisearchSync::afterVodSave((int)$v['vod_id']);
                }

            }
            $param['page']++;
            $url = url('vod/batch') .'?'. http_build_query($param);
            mac_jump( $url ,3);
            exit;
        }

        //分类
        $type_tree = model('Type')->getCache('type_tree');
        $this->assign('type_tree',$type_tree);

        //播放器
        $this->assignBaseListByConfig();
        $this->assign('title',lang('admin/vod/title'));
        return $this->fetch('admin@vod/batch');
    }

    /**
     * 与批量操作页筛选条件一致（用于导出）
     */
    private function vodBatchFilterWhere(&$param)
    {
        $where = [];
        if (!empty($param['type'])) {
            $where['type_id'] = ['eq', $param['type']];
        }
        if (!empty($param['level'])) {
            $where['vod_level'] = ['eq', $param['level']];
        }
        if (in_array($param['status'] ?? '', ['0', '1', '2', '3', '4'])) {
            $where['vod_status'] = ['eq', $param['status']];
        }
        if (in_array($param['copyright'] ?? '', ['0', '1'])) {
            $where['vod_copyright'] = ['eq', $param['copyright']];
        }
        if (in_array($param['isend'] ?? '', ['0', '1'])) {
            $where['vod_isend'] = ['eq', $param['isend']];
        }
        if (!empty($param['lock'])) {
            $where['vod_lock'] = ['eq', $param['lock']];
        }
        if (!empty($param['state'])) {
            $where['vod_state'] = ['eq', $param['state']];
        }
        if (!empty($param['area'])) {
            $where['vod_area'] = ['eq', $param['area']];
        }
        if (!empty($param['lang'])) {
            $where['vod_lang'] = ['eq', $param['lang']];
        }
        if (in_array($param['plot'] ?? '', ['0', '1'])) {
            $where['vod_plot'] = ['eq', $param['plot']];
        }
        if (in_array($param['role'] ?? '', ['0', '1'])) {
            $roleVodIds = Db::name('role')->where('role_rid', '>', 0)->group('role_rid')->column('role_rid');
            if ($param['role'] == '1') {
                if (!empty($roleVodIds)) {
                    $where['vod_id'] = ['in', $roleVodIds];
                } else {
                    $where['vod_id'] = ['eq', 0];
                }
            } else {
                if (!empty($roleVodIds)) {
                    $where['vod_id'] = ['not in', $roleVodIds];
                }
            }
        }
        if (!empty($param['url'])) {
            if ($param['url'] == 1) {
                $where['vod_play_url'] = '';
            }
        }
        if (!empty($param['points'])) {
            $where['vod_points_play|vod_points_down'] = ['gt', 0];
        }
        if (!empty($param['pic'])) {
            if ($param['pic'] == '1') {
                $where['vod_pic'] = ['eq', ''];
            } elseif ($param['pic'] == '2') {
                $where['vod_pic'] = ['like', 'http%'];
            } elseif ($param['pic'] == '3') {
                $where['vod_pic'] = ['like', '%#err%'];
            }
        }
        if (!empty($param['wd'])) {
            $param['wd'] = htmlspecialchars(urldecode($param['wd']));
            $like = mac_search_wd_like($param['wd']);
            if ($like) {
                $where['vod_name'] = $like;
            }
        }
        if (!empty($param['weekday'])) {
            $where['vod_weekday'] = ['like', '%' . $param['weekday'] . '%'];
        }
        if (!empty($param['player'])) {
            if ($param['player'] == 'no') {
                $where['vod_play_from'] = [['eq', ''], ['eq', 'no'], 'or'];
            } else {
                $where['vod_play_from'] = ['like', '%' . $param['player'] . '%'];
            }
        }
        if (!empty($param['downer'])) {
            if ($param['downer'] == 'no') {
                $where['vod_down_from'] = [['eq', ''], ['eq', 'no'], 'or'];
            } else {
                $where['vod_down_from'] = ['like', '%' . $param['downer'] . '%'];
            }
        }
        if (!empty($param['server'])) {
            $where['vod_play_server|vod_down_server'] = ['like', '%' . $param['server'] . '%'];
        }
        if (!empty($param['recycle'])) {
            $where['vod_recycle_time'] = ['>', 0];
        }
        return $where;
    }

    public function exportData()
    {
        $param = input();
        $where = $this->vodBatchFilterWhere($param);
        $this->base_export($param,'vod',$where);
    }

    public function importData()
    {
        $this->base_import('vod');
    }

    public function info()
    {
        if (Request()->isPost()) {
            $param = input('post.');
            if (intval($param['vod_status'] ?? 0) === VodAuditService::STATUS_REJECTED) {
                $remarkErr = VodAuditService::rejectRemarkError($param['vod_audit_remark'] ?? '');
                if ($remarkErr !== '') {
                    return $this->error($remarkErr);
                }
            }
            $publishTime = VodPublishService::parsePublishTime($param['vod_publish_time'] ?? 0);
            $scheduleErr = VodPublishService::scheduleTimeError($param['vod_status'] ?? 0, $publishTime);
            if ($scheduleErr !== '') {
                return $this->error($scheduleErr);
            }
            $contentLang = $param['content_lang'] ?? [];
            unset($param['content_lang']);
            $res = model('Vod')->saveData($param);
            if($res['code']>1){
                return $this->error($res['msg']);
            }
            $vodId = (int)($res['vod_id'] ?? 0);
            if ($vodId > 0 && is_array($contentLang)) {
                //默认语言以原始行为准，只写非默认语言的译文（见 mac_content_lang_overlay 注释）
                $defaultLang = mac_content_lang_default();
                foreach ($contentLang as $langCode => $fields) {
                    if ((string)$langCode === $defaultLang || !is_array($fields)) {
                        continue;
                    }
                    model('ContentLang')->saveFields('vod', $vodId, (string)$langCode, $fields, 'manual', 1);
                }
            }
            return $this->success($res['msg']);
        }

        $id = input('id');
        $where=[];
        $where['vod_id'] = $id;
        $where['_recycle'] = 'all';
        $res = model('Vod')->infoData($where);


        $info = $res['info'];
        $this->assign('info',$info);
        $seoAiStatus = 0;
        if (!empty($info['vod_id'])) {
            $seoAi = model('SeoAiResult')->getByObject(1, intval($info['vod_id']));
            if (!empty($seoAi)) {
                $seoAiStatus = intval($seoAi['seo_status']);
            }
        }
        $this->assign('seo_ai_status', $seoAiStatus);
        $this->assign('vod_ai_cover_can_revert', !empty($info['vod_pic_original']));

        //分类
        $type_tree = model('Type')->getCache('type_tree');
        $this->assign('type_tree',$type_tree);

        //地区、语言
        $config = config('maccms.app');
        $area_list = explode(',',$config['vod_area']);
        $lang_list = explode(',',$config['vod_lang']);
        $this->assign('area_list',$area_list);
        $this->assign('lang_list',$lang_list);

        //用户组
        $group_list = model('Group')->getCache('group_list');
        $this->assign('group_list',$group_list);

        //播放器
        $this->assignBaseListByConfig();

        //播放组、下载租
        $this->assign('vod_play_list',(array)$info['vod_play_list']);
        $this->assign('vod_down_list',(array)$info['vod_down_list']);
        $this->assign('vod_plot_list',(array)$info['vod_plot_list']);


        //内容级多语言：默认语言永远排第一位（即便后台没勾选它），其后跟已启用的其它语言
        $content_lang_default = mac_content_lang_default();
        $content_lang_enabled = array_values(array_unique(array_merge([$content_lang_default], mac_content_lang_allow_list())));
        $content_lang_data = [];
        if (!empty($info['vod_id'])) {
            foreach ($content_lang_enabled as $langCode) {
                $content_lang_data[$langCode] = model('ContentLang')->getFields('vod', $info['vod_id'], $langCode);
            }
        }
        $this->assign('content_lang_default', $content_lang_default);
        $this->assign('content_lang_enabled', $content_lang_enabled);
        $this->assign('content_lang_multi', count($content_lang_enabled) > 1);
        $this->assign('content_lang_data', $content_lang_data);
        $this->assign('content_translate_available', mac_content_translate_available());

        $this->assign('title',lang('admin/vod/title'));
        return $this->fetch('admin@vod/info');
    }

    /**
     * 调用已安装的翻译插件（若有）翻译单个字段；没有插件注册时返回空字符串，前端据此禁用按钮。
     */
    public function contentLangTranslate()
    {
        $text = (string)input('post.text', '');
        $from = (string)input('post.from', mac_content_lang_default());
        $to = (string)input('post.to', '');
        if ($text === '' || $to === '') {
            return $this->error(lang('param_err'));
        }
        if (!mac_content_translate_rate_limit($this->_admin['admin_id'])) {
            return $this->error(lang('frequently'));
        }
        $result = mac_content_translate($text, $from, $to, ['content_type' => 'vod']);
        if ($result === '') {
            return $this->error(lang('admin/vod/content_lang_translate_err'));
        }
        return json(['code' => 1, 'msg' => 'ok', 'data' => $result]);
    }

    public function aiSeoGenerate()
    {
        if (!Request()->isPost()) {
            return json(['code' => 0, 'msg' => lang('illegal_request'), 'data' => []]);
        }
        $id = intval(input('post.id'));
        if ($id <= 0) {
            return json(['code' => 0, 'msg' => lang('param_err'), 'data' => []]);
        }
        try {
            $res = \app\common\util\SeoAi::generateByMidObj(1, $id);
        } catch (\Exception $e) {
            \think\Log::error('AI SEO generate failed (vod_id=' . $id . '): ' . $e->getMessage());
            return json(['code' => 0, 'msg' => $e->getMessage(), 'data' => []]);
        }
        if (empty($res['code']) || intval($res['code']) !== 1) {
            return json(['code' => 0, 'msg' => isset($res['msg']) ? $res['msg'] : lang('save_err'), 'data' => []]);
        }
        return json(['code' => 1, 'msg' => lang('save_ok'), 'data' => isset($res['data']) ? $res['data'] : []]);
    }

    public function aiCoverGenerate()
    {
        if (!Request()->isPost()) {
            return json(['code' => 0, 'msg' => lang('illegal_request'), 'data' => []]);
        }
        $id = intval(input('post.id'));
        if ($id <= 0) {
            return json(['code' => 0, 'msg' => lang('param_err'), 'data' => []]);
        }
        $adminId = intval($this->_admin['admin_id'] ?? 0);
        if (!\app\common\util\VodAiCover::consumeGenerateRateLimit($adminId)) {
            return json(['code' => 0, 'msg' => lang('admin/ai_cover/msg_rate_limit'), 'data' => []]);
        }
        $extraPrompt = input('post.extra_prompt', '', '');
        if (!is_string($extraPrompt)) {
            $extraPrompt = '';
        }
        try {
            $res = \app\common\util\VodAiCover::generateByVodId($id, $extraPrompt);
        } catch (\Exception $e) {
            \think\Log::error('AI cover generate failed (vod_id=' . $id . '): ' . $e->getMessage());
            return json(['code' => 0, 'msg' => $e->getMessage(), 'data' => []]);
        }
        if (empty($res['code']) || intval($res['code']) !== 1) {
            return json(['code' => 0, 'msg' => isset($res['msg']) ? $res['msg'] : lang('save_err'), 'data' => isset($res['data']) ? $res['data'] : []]);
        }
        return json(['code' => 1, 'msg' => isset($res['msg']) ? $res['msg'] : lang('save_ok'), 'data' => isset($res['data']) ? $res['data'] : []]);
    }

    public function aiCoverRevert()
    {
        if (!Request()->isPost()) {
            return json(['code' => 0, 'msg' => lang('illegal_request'), 'data' => []]);
        }
        $id = intval(input('post.id'));
        if ($id <= 0) {
            return json(['code' => 0, 'msg' => lang('param_err'), 'data' => []]);
        }
        try {
            $res = \app\common\util\VodAiCover::revertByVodId($id);
        } catch (\Exception $e) {
            \think\Log::error('AI cover revert failed (vod_id=' . $id . '): ' . $e->getMessage());
            return json(['code' => 0, 'msg' => $e->getMessage(), 'data' => []]);
        }
        if (empty($res['code']) || intval($res['code']) !== 1) {
            return json(['code' => 0, 'msg' => isset($res['msg']) ? $res['msg'] : lang('save_err'), 'data' => isset($res['data']) ? $res['data'] : []]);
        }
        return json(['code' => 1, 'msg' => isset($res['msg']) ? $res['msg'] : lang('save_ok'), 'data' => isset($res['data']) ? $res['data'] : []]);
    }

    public function iplot()
    {
        if (Request()->isPost()) {
            $param = input('post.');
            $res = model('Vod')->savePlot($param);
            if($res['code']>1){
                return $this->error($res['msg']);
            }
            return $this->success($res['msg']);
        }

        $id = input('id');
        $where=[];
        $where['vod_id'] = $id;
        $where['_recycle'] = 'all';
        $res = model('Vod')->infoData($where);


        $info = $res['info'];
        $this->assign('info',$info);
        $this->assign('vod_plot_list',$info['vod_plot_list']);


        $this->assign('title',lang('admin/vod/plot/title'));
        return $this->fetch('admin@vod/iplot');
    }

    public function restore()
    {
        $param = input();
        $ids = $param['ids'];
        if (empty($ids)) {
            return $this->error(lang('param_err'));
        }
        $where = ['vod_id' => ['in', $ids]];
        $res = model('Vod')->restoreData($where);
        if ($res['code'] > 1) {
            return $this->error($res['msg']);
        }
        Cache::rm('vod_repeat_table_created_time');
        return $this->success($res['msg']);
    }

    public function del()
    {
        $param = input();
        $ids = $param['ids'];
        $purge = !empty($param['purge']);

        if(!empty($ids)){
            $where=[];
            $where['vod_id'] = ['in',$ids];
            if ($purge) {
                $res = model('Vod')->delData($where);
            } else {
                $res = model('Vod')->recycleData($where);
            }
            if($res['code']>1){
                return $this->error($res['msg']);
            }
            Cache::rm('vod_repeat_table_created_time');
            return $this->success($res['msg']);
        }
        elseif(!empty($param['repeat'])){
            if($param['retain']=='max') {
                // 保留最大ID - 先用子查询找出要保留的ID
                $sql = 'DELETE FROM '.config('database.prefix').'vod WHERE vod_id IN (
                SELECT * FROM (
                    SELECT v1.vod_id
                    FROM '.config('database.prefix').'vod v1
                    INNER JOIN '.config('database.prefix').'vod v2 
                    ON v1.vod_name = v2.vod_name AND v1.vod_id < v2.vod_id
                ) tmp
            )';
            } else {
                // 保留最小ID - 先用子查询找出要保留的ID
                $sql = 'DELETE FROM '.config('database.prefix').'vod WHERE vod_id IN (
                SELECT * FROM (
                    SELECT v1.vod_id
                    FROM '.config('database.prefix').'vod v1
                    INNER JOIN '.config('database.prefix').'vod v2 
                    ON v1.vod_name = v2.vod_name AND v1.vod_id > v2.vod_id
                ) tmp
            )';
            }

            $res = model('Vod')->execute($sql);
            if($res===false){
                return $this->success(lang('del_err'));
            }
            Cache::rm('vod_repeat_table_created_time');
            return $this->success(lang('del_ok'));
        }
        return $this->error(lang('param_err'));
    }

    public function field()
    {
        $param = input();
        $ids = $param['ids'];
        $col = $param['col'];
        $val = $param['val'];
        $start = $param['start'];
        $end = $param['end'];

        if ($col == 'type_id' && $val==''){
            return $this->error(lang('select_type_must'));
        }
        // 与批量入口同一套白名单：目标分类必须存在且属于视频模块(type_mid=1)。
        // field() 同样是一次改整批数据的入口，表单可被直接构造，写进不存在或跨模块的
        // type_id 后前台按分类取数会整批丢失。取一次缓存供下面复用。
        $type_pid = 0;
        if($col == 'type_id'){
            $type_list = model('Type')->getCache();
            $type_id = intval($val);
            if($type_id < 1 || !isset($type_list[$type_id]) || intval($type_list[$type_id]['type_mid']) != 1){
                return $this->error(lang('select_type_must'));
            }
            $type_pid = intval($type_list[$type_id]['type_pid']);
        }

        if(!empty($ids) && in_array($col,['vod_status','vod_lock','vod_level','vod_hits','type_id','vod_copyright'])){
            $where=[];
            $where['vod_id'] = ['in',$ids];
            $update = [];
            if(empty($start)) {
                if ($col === 'vod_status') {
                    $update[$col] = $val;
                    $remark = trim((string)input('post.remark', input('get.remark', '')));
                    $valStatus = intval($val);
                    if ($valStatus === VodAuditService::STATUS_REJECTED) {
                        $remarkErr = VodAuditService::rejectRemarkError($remark);
                        if ($remarkErr !== '') {
                            return $this->error($remarkErr);
                        }
                        $update['vod_audit_remark'] = mb_substr($remark, 0, 255);
                        $update['vod_publish_time'] = 0;
                    } elseif ($valStatus === VodAuditService::STATUS_APPROVED) {
                        $update['vod_audit_remark'] = '';
                        $update['vod_publish_time'] = 0;
                    } elseif ($valStatus === VodPublishService::STATUS_DRAFT) {
                        $update['vod_publish_time'] = 0;
                    } elseif ($valStatus === VodPublishService::STATUS_SCHEDULED) {
                        $publishTime = VodPublishService::parsePublishTime(input('post.publish_time', input('get.publish_time', 0)));
                        $scheduleErr = VodPublishService::scheduleTimeError(VodPublishService::STATUS_SCHEDULED, $publishTime);
                        if ($scheduleErr !== '') {
                            return $this->error($scheduleErr);
                        }
                        $update['vod_publish_time'] = $publishTime;
                    } else {
                        $update['vod_publish_time'] = 0;
                    }
                } else {
                    $update[$col] = $val;
                }
                if($col == 'type_id'){
                    $update['type_id_1'] = $type_pid;
                }
                $res = model('Vod')->fieldData($where, $update);
            }
            else{
                if(empty($end)){$end = 9999;}
                $ids = explode(',',$ids);
                foreach($ids as $k=>$v){
                    $val = rand($start,$end);
                    $where['vod_id'] = ['eq',$v];
                    $update[$col] = $val;
                    $res = model('Vod')->fieldData($where, $update);
                }
            }
            if($res['code']>1){
                return $this->error($res['msg']);
            }
            return $this->success($res['msg']);
        }
        return $this->error(lang('param_err'));
    }

    /**
     * 批量改审核状态（view_new 专用弹层）
     */
    public function selectStatus()
    {
        $param = input();
        $ids = $param['ids'] ?? '';
        if (empty($ids)) {
            return $this->error(lang('param_err'));
        }
        if (is_array($ids)) {
            $ids = join(',', $ids);
        }
        $this->assign('url', url('field'));
        $this->assign('col', 'vod_status');
        $this->assign('ids', $ids);
        $this->assign('refresh', 'yes');
        return $this->fetch('public/select_vod_status');
    }

    /**
     * 批量审核：通过 / 驳回（可带驳回理由）
     */
    public function audit()
    {
        $param = input();
        $ids = $param['ids'] ?? '';
        $status = intval($param['status'] ?? -1);
        if (empty($ids) || !in_array($status, [1, 2], true)) {
            return $this->error(lang('param_err'));
        }
        $remark = mb_substr(trim((string)($param['remark'] ?? '')), 0, 255);
        if ($status === VodAuditService::STATUS_REJECTED) {
            $remarkErr = VodAuditService::rejectRemarkError($remark);
            if ($remarkErr !== '') {
                return $this->error($remarkErr);
            }
        }

        $where = ['vod_id' => ['in', $ids]];
        $update = ['vod_status' => $status];
        $update['vod_audit_remark'] = $status === 2 ? $remark : '';
        if ($status === VodAuditService::STATUS_APPROVED || $status === VodAuditService::STATUS_REJECTED) {
            $update['vod_publish_time'] = 0;
        }

        $res = model('Vod')->fieldData($where, $update);
        if ($res['code'] > 1) {
            return $this->error($res['msg']);
        }
        return $this->success($res['msg']);
    }

    public function updateToday()
    {
        $param = input();
        $flag = $param['flag'];
        $res = model('Vod')->updateToday($flag);
        return json($res);
    }

    private function assignBaseListByConfig() {
        $player_list = config('vodplayer');
        $downer_list = config('voddowner');
        $server_list = config('vodserver');
        $player_list = mac_multisort($player_list,'sort',SORT_DESC,'status','1');
        $downer_list = mac_multisort($downer_list,'sort',SORT_DESC,'status','1');
        $server_list = mac_multisort($server_list,'sort',SORT_DESC,'status','1');
        $this->assign('player_list',$player_list);
        $this->assign('downer_list',$downer_list);
        $this->assign('server_list',$server_list);
    }
}
