<?php

namespace app\admin\controller;

class TplConfig extends Base
{
    /**
     * 默认模板主题配置
     */
    public function theme()
    {
        if (request()->isPost()) {
            $tplconfig = input();
            if (empty($tplconfig) || !isset($tplconfig['theme'])) {
                return $this->error(lang('param_err'));
            }
            $tplconfig = $tplconfig['theme'];
            if (!isset($tplconfig['banner']) || !is_array($tplconfig['banner'])) {
                $tplconfig['banner'] = [];
            }
            $stylePc = isset($tplconfig['banner']['style_pc']) ? (string)$tplconfig['banner']['style_pc'] : '1';
            $styleH5 = isset($tplconfig['banner']['style_h5']) ? (string)$tplconfig['banner']['style_h5'] : '1';
            $tplconfig['banner']['style_pc'] = in_array($stylePc, ['1', '2', '3', '4'], true) ? $stylePc : '1';
            $tplconfig['banner']['style_h5'] = in_array($styleH5, ['1', '2', '3', '4'], true) ? $styleH5 : '1';
            if (isset($tplconfig['fnav']['ym']) && is_array($tplconfig['fnav']['ym'])) {
                $tplconfig['fnav']['ym'] = join('|', $tplconfig['fnav']['ym']);
            }
            if (isset($tplconfig['show']['filter']) && is_array($tplconfig['show']['filter'])) {
                $tplconfig['show']['filter'] = join('|', $tplconfig['show']['filter']);
            }
            if (isset($tplconfig['ad_slots'])) {
                $tplconfig['ad_slots'] = $this->normalizeAdSlots($tplconfig['ad_slots']);
            }
            if (isset($tplconfig['type']['hom']) && is_array($tplconfig['type']['hom'])) {
                foreach ($tplconfig['type']['hom'] as $hk => $homRow) {
                    if (!is_array($homRow)) {
                        continue;
                    }
                    $cv = isset($homRow['cover']) ? (string) $homRow['cover'] : 'v';
                    $tplconfig['type']['hom'][$hk]['cover'] = ($cv === 'h') ? 'h' : 'v';
                }
            }
            if (!isset($tplconfig['list_cover']) || !is_array($tplconfig['list_cover'])) {
                $tplconfig['list_cover'] = [];
            }
            if (!isset($tplconfig['play']) || !is_array($tplconfig['play'])) {
                $tplconfig['play'] = [];
            }
            $tplconfig['play']['chatroom'] = (isset($tplconfig['play']['chatroom']) && (string)$tplconfig['play']['chatroom'] === '0') ? '0' : '1';
            $vodRows = [];
            if (isset($tplconfig['list_cover']['vod']) && is_array($tplconfig['list_cover']['vod'])) {
                $vodRows = $tplconfig['list_cover']['vod'];
            } elseif (isset($tplconfig['type']['list_cover']) && is_array($tplconfig['type']['list_cover'])) {
                // 兼容旧结构，避免历史配置迁移期间丢失
                $vodRows = $tplconfig['type']['list_cover'];
            }
            $listCoverVod = [];
            foreach ($vodRows as $row) {
                if (!is_array($row) || !isset($row['id']) || (string) $row['id'] === '') {
                    continue;
                }
                $cv = isset($row['cover']) ? (string) $row['cover'] : 'v';
                $listCoverVod[] = [
                    'id' => (string) (int) $row['id'],
                    'cover' => ($cv === 'h') ? 'h' : 'v',
                ];
            }
            $tplconfig['list_cover']['vod'] = $listCoverVod;
            unset($tplconfig['type']['list_cover']);
            if (isset($tplconfig['manga']['hbtn'])) {
                $tplconfig['manga']['hbtn'] = ((string) $tplconfig['manga']['hbtn'] === '1') ? '1' : '0';
            }
            if (isset($tplconfig['manga']['hnum'])) {
                $tplconfig['manga']['hnum'] = ((string) $tplconfig['manga']['hnum'] === '12') ? '12' : '6';
            }
            $mangaCoverRaw = isset($tplconfig['list_cover']['manga'])
                ? (string) $tplconfig['list_cover']['manga']
                : (isset($tplconfig['manga']['cover']) ? (string) $tplconfig['manga']['cover'] : 'v');
            $tplconfig['list_cover']['manga'] = ($mangaCoverRaw === 'h') ? 'h' : 'v';
            if (isset($tplconfig['manga']['cover'])) {
                unset($tplconfig['manga']['cover']);
            }
            if (isset($tplconfig['art']['hbtn'])) {
                $tplconfig['art']['hbtn'] = ((string) $tplconfig['art']['hbtn'] === '1') ? '1' : '0';
            }
            if (isset($tplconfig['art']['hnum'])) {
                $tplconfig['art']['hnum'] = ((string) $tplconfig['art']['hnum'] === '12') ? '12' : '6';
            }
            $artCoverRaw = isset($tplconfig['list_cover']['art'])
                ? (string) $tplconfig['list_cover']['art']
                : (isset($tplconfig['art']['cover']) ? (string) $tplconfig['art']['cover'] : 'v');
            $tplconfig['list_cover']['art'] = ($artCoverRaw === 'h') ? 'h' : 'v';
            if (isset($tplconfig['art']['cover'])) {
                unset($tplconfig['art']['cover']);
            }
            $ratioIn = isset($tplconfig['cover_ratio']) && is_array($tplconfig['cover_ratio'])
                ? $tplconfig['cover_ratio'] : array();
            $ratioDefaults = array('h_w' => 69, 'h_h' => 40, 'v_w' => 20, 'v_h' => 29);
            $ratioOut = array();
            foreach ($ratioDefaults as $ratioKey => $ratioDefault) {
                $raw = isset($ratioIn[$ratioKey]) ? $ratioIn[$ratioKey] : $ratioDefault;
                if ($raw === '' || $raw === null) {
                    $raw = $ratioDefault;
                }
                $ratioOut[$ratioKey] = max(1, min(999, (int) $raw));
            }
            $tplconfig['cover_ratio'] = $ratioOut;
            $listCoverIn = isset($tplconfig['list_cover']) && is_array($tplconfig['list_cover'])
                ? $tplconfig['list_cover'] : array();
            if (!isset($listCoverIn['live']) || !is_array($listCoverIn['live'])) {
                $oldTheme = isset($GLOBALS['mctheme']['theme']) && is_array($GLOBALS['mctheme']['theme'])
                    ? $GLOBALS['mctheme']['theme'] : array();
                $oldListCover = isset($oldTheme['list_cover']) && is_array($oldTheme['list_cover'])
                    ? $oldTheme['list_cover'] : array();
                if (isset($oldListCover['live']) && is_array($oldListCover['live'])) {
                    $listCoverIn['live'] = $oldListCover['live'];
                }
            }
            $tplconfig['list_cover']['live_default'] = $this->resolveLiveListCoverDefault($listCoverIn);
            if (isset($tplconfig['list_cover']['live'])) {
                unset($tplconfig['list_cover']['live']);
            }
            if (isset($tplconfig['topic']['hbtn'])) {
                $tplconfig['topic']['hbtn'] = ((string) $tplconfig['topic']['hbtn'] === '1') ? '1' : '0';
            }
            if (isset($tplconfig['links']['btn'])) {
                $tplconfig['links']['btn'] = ((string) $tplconfig['links']['btn'] === '1') ? '1' : '0';
            }
            if (!isset($tplconfig['badge']) || !is_array($tplconfig['badge'])) {
                $tplconfig['badge'] = [];
            }
            $tplconfig['badge']['serial_btn'] = (isset($tplconfig['badge']['serial_btn']) && (string) $tplconfig['badge']['serial_btn'] === '0') ? '0' : '1';
            $tplconfig['badge']['cover_sub_btn'] = (isset($tplconfig['badge']['cover_sub_btn']) && (string) $tplconfig['badge']['cover_sub_btn'] === '0') ? '0' : '1';
            if (isset($tplconfig['rank']['hbtn'])) {
                $tplconfig['rank']['hbtn'] = ((string) $tplconfig['rank']['hbtn'] === '1') ? '1' : '0';
            }
            if (isset($tplconfig['rank']['btn'])) {
                $tplconfig['rank']['btn'] = ((string) $tplconfig['rank']['btn'] === '1') ? '1' : '0';
            }
            $tplconfig['rank']['boards'] = $this->normalizeRankBoards(
                isset($tplconfig['rank']['boards']) ? $tplconfig['rank']['boards'] : []
            );
            if (isset($tplconfig['nav']) && is_array($tplconfig['nav'])) {
                if (isset($tplconfig['nav']['id'])) {
                    $navIds = preg_replace('/\s+/', '', (string) $tplconfig['nav']['id']);
                    $navIds = trim($navIds, ',');
                    $tplconfig['nav']['id'] = $navIds;
                }
                $tplconfig['nav']['zdybtn'] = (isset($tplconfig['nav']['zdybtn']) && (string) $tplconfig['nav']['zdybtn'] === '1') ? '1' : '0';
                foreach (['zdybtn1', 'zdybtn2', 'zdybtn3', 'zdybtn4'] as $zdyKey) {
                    if (isset($tplconfig['nav'][$zdyKey])) {
                        $tplconfig['nav'][$zdyKey] = ((string) $tplconfig['nav'][$zdyKey] === '1') ? '1' : '0';
                    }
                }
            }
            unset($tplconfig['topic']['hnum']);
            unset($tplconfig['topic']['htitle']);
            $topicCellsIn = isset($tplconfig['topic']['cells']) && is_array($tplconfig['topic']['cells'])
                ? $tplconfig['topic']['cells'] : [];
            $topicCellsNorm = [];
            for ($ti = 0; $ti < 5; $ti++) {
                $trow = isset($topicCellsIn[$ti]) && is_array($topicCellsIn[$ti]) ? $topicCellsIn[$ti] : [];
                $tidRaw = isset($trow['topic_id']) ? (int) $trow['topic_id'] : 0;
                $topicCellsNorm[] = [
                    'topic_id' => (string) ($tidRaw > 0 ? $tidRaw : 0),
                    'title' => isset($trow['title']) ? trim((string) $trow['title']) : '',
                    'sub' => isset($trow['sub']) ? trim((string) $trow['sub']) : '',
                ];
            }
            $tplconfig['topic']['cells'] = $topicCellsNorm;
            if (isset($tplconfig['contact']) && is_array($tplconfig['contact'])) {
                unset($tplconfig['contact']['sdk_js']);
            }
            $tplconfig_new = ['theme' => $tplconfig];
            $tplconfig_old = isset($GLOBALS['mctheme']) && is_array($GLOBALS['mctheme']) ? $GLOBALS['mctheme'] : [];
            $tplconfig_new = array_merge($tplconfig_old, $tplconfig_new);
            $res = mac_save_config_data(APP_PATH . 'extra/mctheme.php', $tplconfig_new);
            if ($res === false) {
                return $this->error(lang('save_err'));
            }
            // 与 ThinkPHP 配置、$GLOBALS 同步，当前请求内模板与 mac_tpl_* 立即生效
            \think\Config::set($tplconfig_new, 'mctheme');
            $GLOBALS['mctheme'] = $tplconfig_new;
            return $this->success(lang('save_ok'));
        }

        $tplconfig = isset($GLOBALS['mctheme']) ? $GLOBALS['mctheme'] : (config('mctheme') ?: ['theme' => []]);
        $type_tree = model('Type')->getCache('type_tree');
        if (!is_array($type_tree)) {
            $type_tree = [];
        }
        if (empty($tplconfig['theme']['rank']['boards']) || !is_array($tplconfig['theme']['rank']['boards'])) {
            $tplconfig['theme']['rank']['boards'] = $this->buildDefaultRankBoards($tplconfig);
        }
        $this->assign('tplconfig', $tplconfig);
        $this->assign('type_tree', $type_tree);
        $this->assign('theme_type_options', $this->buildThemeTypeOptions($type_tree));
        $this->assign('theme_type_index', $this->buildThemeTypeIndex($type_tree));
        $this->assignThemeListCoverViewVars($tplconfig);
        $this->assignThemeUxI18n();
        $this->assign('title', lang('menu/theme/config'));
        return $this->fetch('admin@tplconfig/theme');
    }

    /**
     * 排行榜页多榜单配置归一化：过滤未填写的空行，限制条数与每榜视频数区间，
     * 提交时的行顺序即前台展示顺序（对应表单的拖动排序）。
     */
    protected function normalizeRankBoards($boards)
    {
        if (!is_array($boards)) {
            return [];
        }
        $out = [];
        foreach ($boards as $row) {
            if (!is_array($row)) {
                continue;
            }
            $title = isset($row['title']) ? mac_filter_xss(trim((string) $row['title'])) : '';
            $typeId = isset($row['type_id']) ? (int) $row['type_id'] : 0;
            if ($title === '' && $typeId <= 0) {
                continue;
            }
            $num = isset($row['num']) ? (int) $row['num'] : 6;
            $num = max(2, min(30, $num ?: 6));
            $status = (isset($row['status']) && (string) $row['status'] === '0') ? '0' : '1';
            $out[] = [
                'title'   => $title,
                'type_id' => (string) max(0, $typeId),
                'num'     => (string) $num,
                'status'  => $status,
            ];
            if (count($out) >= 20) {
                break;
            }
        }
        return $out;
    }

    /**
     * 首次进入排行榜配置页（尚未保存过 boards）时，用旧版单一榜单字段
     * （rank.id/rank.num/rank.title）拼出一份初始榜单列表，避免老站点升级后表单看起来是空的。
     */
    protected function buildDefaultRankBoards($tplconfig)
    {
        $rankCfg = (isset($tplconfig['theme']['rank']) && is_array($tplconfig['theme']['rank'])) ? $tplconfig['theme']['rank'] : [];
        $legacyIds = trim((string) ($rankCfg['hid'] ?? ($rankCfg['id'] ?? '')));
        $legacyNum = (int) ($rankCfg['num'] ?? 6);
        $legacyNum = max(2, min(30, $legacyNum ?: 6));

        $boards = [];
        if ($legacyIds !== '' && $legacyIds !== 'parent') {
            $typeModel = model('Type');
            foreach (array_filter(array_map('intval', explode(',', $legacyIds))) as $tid) {
                $info = $typeModel->getCacheInfo($tid);
                $name = !empty($info['type_name']) ? (string) $info['type_name'] : '';
                $boards[] = [
                    'title'   => $name,
                    'type_id' => (string) $tid,
                    'num'     => (string) $legacyNum,
                    'status'  => '1',
                ];
            }
        }
        if (empty($boards)) {
            $boards[] = [
                'title'   => '全站',
                'type_id' => '0',
                'num'     => (string) $legacyNum,
                'status'  => '1',
            ];
        }
        return $boards;
    }

    /**
     * 主题配置页分类选择器：按 type_mid 分组的选项（1=视频 2=文章 12=漫画，all=全部）
     */
    protected function buildThemeTypeOptions(array $type_tree)
    {
        $midLabels = [
            1 => lang('vod'),
            2 => lang('art'),
            12 => lang('admin/tpl/config/type_mid_manga'),
        ];
        $groups = ['1' => [], '2' => [], '12' => [], 'all' => []];
        $push = function ($row, $depth = 0) use (&$groups, $midLabels) {
            $id = isset($row['type_id']) ? (string) $row['type_id'] : '';
            if ($id === '') {
                return;
            }
            $mid = isset($row['type_mid']) ? (int) $row['type_mid'] : 0;
            $name = isset($row['type_name']) ? (string) $row['type_name'] : '';
            $label = preg_replace('/^—\s*/u', '', $name);
            $item = [
                'id' => $id,
                'name' => $name,
                'label' => $label,
                'depth' => $depth,
            ];
            if (isset($groups[(string) $mid])) {
                $groups[(string) $mid][] = $item;
            }
            $prefix = isset($midLabels[$mid]) ? '[' . $midLabels[$mid] . '] ' : '';
            $groups['all'][] = [
                'id' => $id,
                'name' => $prefix . $name,
                'label' => $prefix . $label,
                'depth' => $depth,
                'mid' => $mid,
            ];
        };
        foreach ($type_tree as $vo) {
            if (!is_array($vo)) {
                continue;
            }
            $push($vo, 0);
            if (!empty($vo['child']) && is_array($vo['child'])) {
                foreach ($vo['child'] as $ch) {
                    if (!is_array($ch)) {
                        continue;
                    }
                    $chRow = $ch;
                    if (!isset($chRow['type_mid']) && isset($vo['type_mid'])) {
                        $chRow['type_mid'] = $vo['type_mid'];
                    }
                    $chRow['type_name'] = '— ' . (isset($ch['type_name']) ? (string) $ch['type_name'] : '');
                    $push($chRow, 1);
                }
            }
        }
        return $groups;
    }

    /**
     * 主题配置页 JS 文案（分类选择器、排序等）
     */
    protected function assignThemeUxI18n()
    {
        $this->assign('theme_ux_i18n_json', json_encode([
            'midLabels' => [
                '1' => lang('vod'),
                '2' => lang('art'),
                '12' => lang('admin/tpl/config/type_mid_manga'),
            ],
            'midTabs' => [
                ['id' => 'all', 'title' => lang('all')],
                ['id' => '1', 'title' => lang('vod')],
                ['id' => '2', 'title' => lang('art')],
                ['id' => '12', 'title' => lang('admin/tpl/config/type_mid_manga')],
            ],
            'pickType' => lang('admin/tpl/config/type_picker_btn'),
            'pickNavMulti' => lang('admin/tpl/config/type_picker_nav_multi'),
            'pickMulti' => lang('admin/tpl/config/type_picker_multi'),
            'selectedCount' => lang('admin/tpl/config/type_picker_selected_count'),
            'removeType' => lang('admin/tpl/config/type_picker_remove'),
            'noneSelectedHint' => lang('admin/tpl/config/type_picker_none_hint'),
            'selectedHead' => lang('admin/tpl/config/type_picker_selected_head'),
            'idInvalid' => lang('admin/tpl/config/type_picker_id_invalid'),
            'emptyMulti' => lang('admin/tpl/config/type_picker_empty_multi'),
            'emptySingle' => lang('admin/tpl/config/type_picker_empty_single'),
            'closeEsc' => lang('admin/tpl/config/type_picker_close_esc'),
            'close' => lang('admin/tpl/config/type_picker_close'),
            'searchPh' => lang('admin/tpl/config/type_picker_search_ph'),
            'dragSort' => lang('admin/tpl/config/type_picker_drag_sort'),
            'clearAll' => lang('admin/tpl/config/type_picker_clear_all'),
            'unbind' => lang('admin/tpl/config/type_picker_unbind'),
            'confirm' => lang('admin/tpl/config/type_picker_confirm'),
            'reset' => lang('admin/tpl/config/type_picker_reset'),
            'multiMeta' => lang('admin/tpl/config/type_picker_multi_meta'),
            'singleMeta' => lang('admin/tpl/config/type_picker_single_meta'),
            'hotvodTabLabel' => lang('admin/tpl/config/hotvod_tab_label'),
            'rankBoardLabel' => lang('admin/tpl/config/rank_boards_row_label'),
        ], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP));
    }

    /**
     * type_id => {id, name, mid}，供前端回显 Tab 与失效 ID
     */
    protected function buildThemeTypeIndex(array $type_tree)
    {
        $index = [];
        $walk = function ($row) use (&$index, &$walk) {
            if (!is_array($row) || !isset($row['type_id'])) {
                return;
            }
            $id = (string) $row['type_id'];
            $index[$id] = [
                'id' => $id,
                'name' => isset($row['type_name']) ? (string) $row['type_name'] : '',
                'mid' => isset($row['type_mid']) ? (int) $row['type_mid'] : 0,
            ];
            if (!empty($row['child']) && is_array($row['child'])) {
                foreach ($row['child'] as $ch) {
                    if (is_array($ch)) {
                        $walk($ch);
                    }
                }
            }
        };
        foreach ($type_tree as $vo) {
            $walk($vo);
        }
        return $index;
    }

    /**
     * 广告位配置规范化（固定结构）：
     * slot => ['ad_type_id' => ?, 'ad_data' => [ ... ]]
     */
    protected function normalizeAdSlots($adSlots)
    {
        if (!is_array($adSlots)) {
            return [];
        }
        $slotMeta = [
            'banner1' => ['ad_type_id' => 1, 'area' => 'hengfu1'],
            'banner_swiper' => ['ad_type_id' => 4, 'area' => 'lunbo'],
            'icon1' => ['ad_type_id' => 2, 'area' => 'tubiao1'],
            'bottom' => ['ad_type_id' => 3, 'area' => 'dipiao'],
            'sitejs' => ['ad_type_id' => null, 'area' => 'js'],
        ];
        $fields = ['id', 'area', 'order', 'name', 'url', 'image', 'height', 'text', 'code', 'active', 'date', 'note'];
        $normalized = [];
        foreach ($slotMeta as $slot => $meta) {
            $normalized[$slot] = ['ad_type_id' => $meta['ad_type_id'], 'ad_data' => []];
            if (empty($adSlots[$slot]) || !is_array($adSlots[$slot]) || empty($adSlots[$slot]['ad_data']) || !is_array($adSlots[$slot]['ad_data'])) {
                continue;
            }
            if (array_key_exists('ad_type_id', $adSlots[$slot])) {
                $normalized[$slot]['ad_type_id'] = $adSlots[$slot]['ad_type_id'] === '' ? null : $adSlots[$slot]['ad_type_id'];
            }
            foreach ($adSlots[$slot]['ad_data'] as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $item = [];
                foreach ($fields as $field) {
                    $value = isset($row[$field]) ? trim((string)$row[$field]) : '';
                    if ($field === 'order') {
                        $value = (string)intval($value);
                    } elseif ($field === 'active') {
                        $value = strtolower($value) === 'on' ? 'on' : 'off';
                    }
                    $item[$field] = $value;
                }
                $item['area'] = $meta['area'];

                // 至少有一个有效业务字段才保留，避免空行写入配置
                $hasPayload = false;
                $payloadFields = ['url', 'image', 'code', 'text', 'name', 'note'];
                foreach ($payloadFields as $k) {
                    if (!empty($item[$k])) { $hasPayload = true; break; }
                }
                if ($hasPayload) {
                    $normalized[$slot]['ad_data'][] = $item;
                }
            }
        }
        return $normalized;
    }

    /**
     * 列表封面 Tab：封面比例、漫画/资讯/直播方向等表单默认值（服务端渲染，勿在模板写 {php}）
     */
    protected function assignThemeListCoverViewVars(array $tplconfig)
    {
        $theme = isset($tplconfig['theme']) && is_array($tplconfig['theme']) ? $tplconfig['theme'] : array();
        $listCover = isset($theme['list_cover']) && is_array($theme['list_cover']) ? $theme['list_cover'] : array();
        $coverRatio = isset($theme['cover_ratio']) && is_array($theme['cover_ratio']) ? $theme['cover_ratio'] : array();

        $mangaRaw = isset($listCover['manga']) ? (string) $listCover['manga'] : 'v';
        $artRaw = isset($listCover['art']) ? (string) $listCover['art'] : 'v';
        $this->assign('mangaListCover', ($mangaRaw === 'h') ? 'h' : 'v');
        $this->assign('artListCover', ($artRaw === 'h') ? 'h' : 'v');
        $this->assign('liveListCoverDefault', $this->resolveLiveListCoverDefault($listCover));
        $this->assign('posterRatioH_W', max(1, min(999, (int) (isset($coverRatio['h_w']) ? $coverRatio['h_w'] : 69))));
        $this->assign('posterRatioH_H', max(1, min(999, (int) (isset($coverRatio['h_h']) ? $coverRatio['h_h'] : 40))));
        $this->assign('posterRatioV_W', max(1, min(999, (int) (isset($coverRatio['v_w']) ? $coverRatio['v_w'] : 20))));
        $this->assign('posterRatioV_H', max(1, min(999, (int) (isset($coverRatio['v_h']) ? $coverRatio['v_h'] : 29))));
    }

    /**
     * 直播列表封面方向：优先 live_default；兼容旧版 list_cover.live 按分类配置（取首个有效值）
     */
    protected function resolveLiveListCoverDefault(array $listCover)
    {
        if (isset($listCover['live_default'])) {
            return ((string) $listCover['live_default'] === 'h') ? 'h' : 'v';
        }
        if (isset($listCover['live']) && is_array($listCover['live'])) {
            foreach ($listCover['live'] as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $cover = isset($row['cover']) ? (string) $row['cover'] : '';
                if ($cover === 'h' || $cover === 'v') {
                    return $cover;
                }
            }
        }
        return 'v';
    }
}
